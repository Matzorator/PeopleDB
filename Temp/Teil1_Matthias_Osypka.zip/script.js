//Warten bis DOM geladen
document.addEventListener("DOMContentLoaded", function () {
  // Array Hartcodiert mit Daten jeweils als Objekt
  const mitarbeiter = [
    {
      id: 1,
      bild: "images/maxmustermann.webp",
      vorname: "Max",
      name: "Mustermann",
      email: "max@firm.de",
      phone: "123-456-7890",
      abteilung: "Vertrieb",
      position: "Verkaufsleiter",
      bemerkung: "Teamleiter seit 2019, betreut Großkunden im DACH-Raum",
      gehalt: "5000€ pro Monat Brutto",
    },
    {
      id: 2,
      bild: "images/janedoe.webp",
      vorname: "Jane",
      name: "Doe",
      email: "jane@firm.de",
      phone: "098-765-4321",
      abteilung: "IT",
      position: "Senior Developer",
      bemerkung: "Spezialisiert auf Backend-Entwicklung, Python & Node.js",
      gehalt: "6000€ pro Monat Brutto",
    },
    {
      id: 3,
      bild: "images/jondoe.webp",
      vorname: "John",
      name: "Doe",
      email: "john@firm.de",
      phone: "011-223-3445",
      abteilung: "IT",
      position: "Frontend Developer",
      bemerkung: "React-Experte, arbeitet remote aus Berlin",
      gehalt: "5500€ pro Monat Brutto",
    },
    {
      id: 4,
      bild: "images/sarahmueller.webp",
      vorname: "Sarah",
      name: "Müller",
      email: "sarah@firm.de",
      phone: "022-334-4556",
      abteilung: "HR",
      position: "Personalleiterin",
      bemerkung: "Verantwortlich für Recruiting und Mitarbeiterentwicklung",
      gehalt: "4800€ pro Monat Brutto",
    },
    {
      id: 5,
      bild: "images/thomasschmidt.webp",
      vorname: "Thomas",
      name: "Schmidt",
      email: "thomas@firm.de",
      phone: "033-445-5667",
      abteilung: "Marketing",
      position: "Marketing Manager",
      bemerkung: "Leitet digitale Kampagnen, 5 Jahre Erfahrung im B2B",
      gehalt: "4500€ pro Monat Brutto",
    },
    {
      id: 6,
      bild: "images/lauraweiss.webp",
      vorname: "Laura",
      name: "Weiss",
      email: "laura@firm.de",
      phone: "044-556-6778",
      abteilung: "Finanzen",
      position: "Buchhalterin",
      bemerkung: "Zuständig für Lohnbuchhaltung und Jahresabschluss",
      gehalt: "3800€ pro Monat Brutto",
    },
    {
      id: 7,
      bild: "images/michaelbecker.webp",
      vorname: "Michael",
      name: "Becker",
      email: "michael@firm.de",
      phone: "055-667-7889",
      abteilung: "Vertrieb",
      position: "Account Manager",
      bemerkung: "Betreut Neukunden in der Region Nordrhein-Westfalen",
      gehalt: "4200€ pro Monat Brutto",
    },
    {
      id: 8,
      bild: "images/annakoch.webp",
      vorname: "Anna",
      name: "Koch",
      email: "anna@firm.de",
      phone: "066-778-8990",
      abteilung: "IT",
      position: "QA Testerin",
      bemerkung: "Automatisierte Tests, Scrum Master Zertifikat",
      gehalt: "4700€ pro Monat Brutto",
    },
  ];

  let aktuelleDaten = [...mitarbeiter];

  // DOM-Elemente
  const tabelleBody = document.getElementById("tabelleBody");
  const sucheInput = document.getElementById("suche");
  const modal = document.getElementById("detailModal");
  const detailContent = document.getElementById("detailContent");
  const closeModal = document.querySelector(".close");

  // Render Tabelle

  function renderTabelle(daten) {
    tabelleBody.innerHTML = "";
    daten.forEach((mitarbeiter) => {
      const row = document.createElement("tr");
      row.innerHTML = `
      <td data-label="Bild"><img src="${mitarbeiter.bild}" alt="${mitarbeiter.vorname} ${mitarbeiter.name}"></td>
      <td data-label="Vorname">${mitarbeiter.vorname}</td>
      <td data-label="Name">${mitarbeiter.name}</td>
      <td data-label="E-Mail">${mitarbeiter.email}</td>
      <td data-label="Telefon">${mitarbeiter.phone}</td>
      <td data-label="Abteilung">${mitarbeiter.abteilung}</td>      
      <td data-label="Aktion"><button class="detailBtn" data-id="${mitarbeiter.id}">Details</button></td>
    `;
      tabelleBody.appendChild(row);
    });
  }

  // Detail-Modal anzeigen
  function zeigeDetails(mitarbeiter) {
    detailContent.innerHTML = `
      <img src="${mitarbeiter.bild}" alt="${mitarbeiter.vorname} ${mitarbeiter.name}" width="100">
      <p><strong>Vorname:</strong> ${mitarbeiter.vorname}</p>
      <p><strong>Name:</strong> ${mitarbeiter.name}</p>
      <p><strong>E-Mail:</strong> ${mitarbeiter.email}</p>
      <p><strong>Telefon:</strong> ${mitarbeiter.phone}</p>
      <p><strong>Abteilung:</strong> ${mitarbeiter.abteilung}</p>
      <p><strong>Position:</strong> ${mitarbeiter.position}</p>
      <p><strong>Bemerkung:</strong> ${mitarbeiter.bemerkung}</p>
      <p><strong>Gehalt:</strong> ${mitarbeiter.gehalt}</p>
    `;
    modal.classList.remove("hidden");
  }

  // Event-Handler für Klicks
  document.addEventListener("click", function (event) {
    // Details-Button geklickt
    if (event.target.classList.contains("detailBtn")) {
      console.log("✅ Detail-Button geklickt!");
      const id = parseInt(event.target.dataset.id);
      const gefundeneMitarbeiter = mitarbeiter.find((m) => m.id === id);
      if (gefundeneMitarbeiter) {
        zeigeDetails(gefundeneMitarbeiter);
      }
      return;
    }

    // Modal schließen (X oder Hintergrund)
    if (event.target.classList.contains("close") || event.target === modal) {
      modal.classList.add("hidden");
    }
  });

  // Suche
  sucheInput.addEventListener("input", function () {
    const suchbegriff = sucheInput.value.toLowerCase();
    aktuelleDaten = mitarbeiter.filter(
      (m) =>
        m.vorname.toLowerCase().includes(suchbegriff) ||
        m.name.toLowerCase().includes(suchbegriff) ||
        m.abteilung.toLowerCase().includes(suchbegriff) ||
        m.position.toLowerCase().includes(suchbegriff),
    );
    renderTabelle(aktuelleDaten);
  });

  // START: Initiale Tabelle rendern
  renderTabelle(aktuelleDaten);
});

// Das wars erstmal für heute :)
